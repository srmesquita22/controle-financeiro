import './bootstrap';
import Alpine from 'alpinejs';
import toastr from 'toastr'; // Importe o Toastr

window.toastr = toastr; // Adicione o Toastr ao objeto global window

document.addEventListener('DOMContentLoaded', function() {
    // Configuração do Toastr
    toastr.options = {
        closeButton: true,
        progressBar: true,
        positionClass: 'toast-top-right',
        preventDuplicates: true,
        showDuration: '300',
        hideDuration: '1000',
        timeOut: '5000',
        extendedTimeOut: '1000',
        showEasing: 'swing',
        hideEasing: 'linear',
        showMethod: 'fadeIn',
        hideMethod: 'fadeOut'
    };

    // Certifique-se de que o Toastr está disponível globalmente
    window.toastr = toastr;

    // Inicialize o AlpineJS
    window.Alpine = Alpine;
    Alpine.start();
});
